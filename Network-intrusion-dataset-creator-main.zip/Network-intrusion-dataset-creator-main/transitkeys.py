# the keys in the dictionary that is passed across the queues

key_id = "Id"
key_packet = "Packet"
key_protocol = "Protocol"
key_services = "Services"