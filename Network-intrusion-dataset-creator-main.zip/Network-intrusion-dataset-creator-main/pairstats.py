class pair_stats_tcp:
    src = 0
    dst = 0
    count = 0
    # tcp.srcport
    # tcp.dstport
    # tcp.flags.res
    # tcp.flags.ns
    # tcp.flags.cwr
    # tcp.flags.ecn
    # tcp.flags.urg
    # tcp.flags.ack
    # tcp.flags.push
    # tcp.flags.reset
    # tcp.flags.syn
    # tcp.flags.fin


class pair_stats_udp:
    src = 0
    dst = 0
    count = 0
    # udp.srcport
    # udp.dstport


class pair_stats_arp:
    src = 0
    dst = 0
    count = 0
    # arp.src.hw_mac
    # arp.dst.hw_mac
